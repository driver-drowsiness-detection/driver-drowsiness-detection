"""Measurement records and overlays."""
